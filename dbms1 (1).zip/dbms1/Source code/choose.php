<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<!DOCTYPE html>
<html>
<head>
	<title>Choose</title>
</head>
<center>
<body>

	<style type="text/css">
	
	#text{

		height: 25px;
		border-radius: 5px;
		color: blue;
		padding: 4px;
		border: solid thin #aaa;
		width: 100%;
	}

	body {
    background-image: url("p2.jpg");
	background-size: 100%;
	background-color: #cccccc;
	}

	h1 {
  color: #FFCC80;
   }
	#button{

		padding: 10px;
		width: 100px;
		color: white;
		background-color: lightblue;
		border: none;
	}
	

	#box{

		background-color: lightblue;
		margin: auto;
		width: 300px;
		padding: 20px;
	}

	</style>
	<br><br>	<br>
	<br>

	<h1> Mentor-Student System</h1>
	<br><br><br>

	<div id="box">
		<form method="post">
	
		<h1>	<div style="font-size: 20px;margin: 10px;color:#FF9800;">Choose role :</div></h6>
		<br><a class="btn btn-primary" href="Student_reg.php" role="button">Student</a><br><br>
		<br><a class="btn btn-primary" href="Mreg.php" role="button">Mentor</a>
		</form>
	</div>
</body>
</center>
</html>