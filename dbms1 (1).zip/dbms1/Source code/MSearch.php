<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

<!DOCTYPE html>
<html>
<head>
	<title>MSearch</title>
</head>
<center>
<body>

	<style type="text/css">
	
	#text{

		height: 25px;
		border-radius: 5px;
		padding: 4px;
		border: solid thin #aaa;
		width: 100%;
	}

	#button{

		padding: 10px;
		width: 100px;
		color: white;
		background-color: lightblue;
		border: none;
	}

	#box{

		background-color: lightblue;
		margin: auto;
		width: 400px;
		padding: 20px;
	}

	</style>
<br>
	<div id="box">
	<br>
		<form method="post">
		<h1>	<div style="font-size: 20px;margin: 10px;color: black;">Choose filter for Mentor search :</div></h6>
		<br>
		<br><a class="btn btn-primary" href="searchengine_sub.php" role="button">By Subject</a><br><br>
		<br><a class="btn btn-primary" href="City_search.php" role="button">By City</a><br><br>
		</form>
	</div>
</body>
</center>
</html>